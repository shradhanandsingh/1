import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from './api.service';
import { dataType } from './data.model';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  reactiveForm: FormGroup;
  title = 'reactive';
  reactiveFormsDetails:any =[];
  public dataValue: dataType;
  constructor(private fb: FormBuilder,private service: ApiService,) {
  }

  ngOnInit() {
    this.createForm();
  }

  createForm(){
    this.reactiveForm = this.fb.group({
      fName: ['', Validators.required],
      lName: ['', Validators.required],
      phoneno: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],
      email: ['', [Validators.required, Validators.email]]
    })
  }

  onSubmit() {
   
   this.service.createData(this.reactiveForm.value).subscribe( res=>{
     this.dataValue=res;
console.log("ff",this.reactiveForm.value);

// reset form 
    setTimeout(() => {
      this.reactiveForm.reset();
    }, 1000);
// reset form end 

    this.reactiveFormsDetails.push(this.reactiveForm.value)
    console.log("faha", this.reactiveFormsDetails)
   })
  }

  _keyPress(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
        event.preventDefault();
    }
}
reset(){
     this.reactiveForm.reset();

}

}
