import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { dataType } from './data.model';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  baseUrl: string = environment.baseUrl;
  constructor(private httpClient: HttpClient) { }
  public createData(data) { 
    console.log(data)
    
    const endpoint = "employ.json ";
    return this.httpClient.post<dataType>(`${this.baseUrl}/${endpoint}`, data).pipe
    (map(data => (data)));
  }

}
