export class dataType {
    fName: string;
    lName: string;
    phoneno: string;
    email: string;
}